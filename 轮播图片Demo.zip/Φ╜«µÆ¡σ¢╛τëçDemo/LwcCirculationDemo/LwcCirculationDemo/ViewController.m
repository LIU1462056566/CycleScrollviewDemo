//
//  ViewController.m
//  LwcCirculationDemo
//
//  Created by 张晴顺 on 2017/6/1.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import "ViewController.h"
#import "LWCCirCulateView.h"
#define SCREEN_WINTH  [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT  [UIScreen mainScreen].bounds.size.height
@interface ViewController ()
@property(nonatomic,strong)LWCCirCulateView *MycollecView;
@end

@implementation ViewController

-(LWCCirCulateView *)MycollecView
{
    if (!_MycollecView) {
        
        
        UICollectionViewLayout *flowLayout=[[UICollectionViewLayout alloc]init];
        _MycollecView=[[LWCCirCulateView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WINTH, SCREEN_HEIGHT) collectionViewLayout:flowLayout];
        
    }return _MycollecView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
  
    [self.view addSubview:self.MycollecView];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
